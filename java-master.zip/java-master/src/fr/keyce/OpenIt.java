package fr.keyce;

public class OpenIt {

	public static void main(String[] args) {
		Menu menu = new Menu();
		menu.displayMenu();
	}
}
