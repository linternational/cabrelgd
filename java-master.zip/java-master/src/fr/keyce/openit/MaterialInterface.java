package fr.keyce.openit;

public interface MaterialInterface {

	public float getPrice();

	public void setName(String name);

	public void setSerialNumber(String serialNumber);
}
